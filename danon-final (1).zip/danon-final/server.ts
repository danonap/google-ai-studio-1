import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Contact Form
  app.post("/api/contact", async (req, res) => {
    const { name, email, market, packageInterest, details } = req.body;
    
    console.log("Received contact form submission:", { name, email, market, packageInterest, details });

    // In a real app, you would use Resend or another email service here.
    // Since we don't have a Resend API key, we'll simulate a successful send.
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // For now, we just return success.
    res.json({ 
      success: true, 
      message: "Inquiry received. We will get back to you soon." 
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
