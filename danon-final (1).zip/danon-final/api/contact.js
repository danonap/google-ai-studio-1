export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { name, email, market, packageInterest, details } = req.body;

  if (!name || !email) {
    return res.status(400).json({ error: 'Name and email are required' });
  }

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: 'Danon Aerial Website <onboarding@resend.dev>',
        to: 'danonaerialphotography@gmail.com',
        reply_to: email,
        subject: `New Inquiry from ${name} — Danon Aerial Photography`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 32px; background: #f9f9f9;">
            <div style="background: #0A0A0A; padding: 24px; border-radius: 8px 8px 0 0;">
              <h1 style="color: #C9A84C; margin: 0; font-size: 22px; letter-spacing: 2px;">DANON AERIAL PHOTOGRAPHY</h1>
              <p style="color: #9A9286; margin: 4px 0 0; font-size: 13px;">New Website Inquiry</p>
            </div>
            <div style="background: #ffffff; padding: 32px; border-radius: 0 0 8px 8px; border: 1px solid #e0e0e0;">
              <table style="width: 100%; border-collapse: collapse;">
                <tr>
                  <td style="padding: 12px 0; color: #666; font-size: 13px; width: 160px; border-bottom: 1px solid #f0f0f0;"><strong>Name</strong></td>
                  <td style="padding: 12px 0; font-size: 14px; border-bottom: 1px solid #f0f0f0;">${name}</td>
                </tr>
                <tr>
                  <td style="padding: 12px 0; color: #666; font-size: 13px; border-bottom: 1px solid #f0f0f0;"><strong>Email</strong></td>
                  <td style="padding: 12px 0; font-size: 14px; border-bottom: 1px solid #f0f0f0;"><a href="mailto:${email}" style="color: #C9A84C;">${email}</a></td>
                </tr>
                <tr>
                  <td style="padding: 12px 0; color: #666; font-size: 13px; border-bottom: 1px solid #f0f0f0;"><strong>Market</strong></td>
                  <td style="padding: 12px 0; font-size: 14px; border-bottom: 1px solid #f0f0f0;">${market || 'Not specified'}</td>
                </tr>
                <tr>
                  <td style="padding: 12px 0; color: #666; font-size: 13px; border-bottom: 1px solid #f0f0f0;"><strong>Package Interest</strong></td>
                  <td style="padding: 12px 0; font-size: 14px; border-bottom: 1px solid #f0f0f0;">${packageInterest || 'Not specified'}</td>
                </tr>
                <tr>
                  <td style="padding: 12px 0; color: #666; font-size: 13px; vertical-align: top;"><strong>Details</strong></td>
                  <td style="padding: 12px 0; font-size: 14px;">${details ? details.replace(/\n/g, '<br>') : 'No details provided'}</td>
                </tr>
              </table>
              <div style="margin-top: 24px; padding: 16px; background: #f5f5f5; border-radius: 6px; font-size: 12px; color: #999;">
                Reply directly to this email to respond to ${name}.
              </div>
            </div>
          </div>
        `
      })
    });

    if (!response.ok) {
      const error = await response.json();
      console.error('Resend error:', error);
      return res.status(500).json({ error: 'Failed to send email' });
    }

    return res.status(200).json({ success: true });

  } catch (err) {
    console.error('Server error:', err);
    return res.status(500).json({ error: 'Server error' });
  }
}
