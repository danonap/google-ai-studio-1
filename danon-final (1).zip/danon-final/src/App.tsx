import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Camera, 
  Video, 
  Home, 
  Share2, 
  ChevronRight, 
  Check, 
  MapPin, 
  Mail, 
  Phone, 
  Instagram, 
  Facebook, 
  Linkedin,
  Menu,
  X,
  ArrowRight,
  Star
} from 'lucide-react';

// --- Types ---
interface Package {
  id: string;
  name: string;
  price: string;
  deliverables: string[];
  turnaround: string;
  featured?: boolean;
  stripeUrl: string;
}

// --- Constants ---
const PACKAGES: Package[] = [
  {
    id: 'starter',
    name: 'Starter',
    price: '275',
    deliverables: ['5 aerial photos', 'Horizontal + vertical formats', '48-hr delivery', 'Aerial only, no interior'],
    turnaround: '48 hours',
    stripeUrl: 'REPLACE_WITH_STRIPE_LINK_STARTER_275'
  },
  {
    id: 'standard',
    name: 'Standard',
    price: '400',
    deliverables: ['8 aerial photos', '30-sec 4K aerial video', 'Horizontal + vertical formats', '48-hr delivery', 'Aerial only with video'],
    turnaround: '48 hours',
    stripeUrl: 'REPLACE_WITH_STRIPE_LINK_STANDARD_400'
  },
  {
    id: 'premium',
    name: 'Premium',
    price: '750',
    deliverables: ['10 aerial photos', '30-sec 4K aerial video', 'Full interior photography', 'Exterior ground photography', 'Social media reels'],
    turnaround: '72 hours',
    featured: true,
    stripeUrl: 'REPLACE_WITH_STRIPE_LINK_PREMIUM_750'
  },
  {
    id: 'full-production',
    name: 'Full Production',
    price: '1,100',
    deliverables: ['Everything in Premium', 'Extended interior coverage', '3–5 social media cuts', 'Dedicated editing session'],
    turnaround: '24 hours',
    stripeUrl: 'REPLACE_WITH_STRIPE_LINK_FULLPRODUCTION_1100'
  }
];

const SERVICES = [
  {
    title: 'Aerial Photography',
    description: '4K stills, horizontal + vertical formats, MLS and social ready, sub-250g drone flexibility.',
    icon: Camera
  },
  {
    title: 'Aerial Videography',
    description: 'Cinematic 4K flyover footage, property videos, short-form social cuts.',
    icon: Video
  },
  {
    title: 'Interior Photography',
    description: 'Professional indoor photography, natural light, clean composition, fast turnaround.',
    icon: Home
  },
  {
    title: 'Social Media Content',
    description: 'Platform-optimized vertical and horizontal cuts for Reels, TikTok, Facebook, YouTube.',
    icon: Share2
  }
];

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Packages', href: '#packages' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'glass-nav py-4' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <a href="#hero" className="flex flex-col group">
          <span className="text-2xl font-display font-medium tracking-wider text-gold group-hover:text-gold-light transition-colors">
            DANON AERIAL
          </span>
          <div className="h-[1px] w-full bg-gold/30 group-hover:bg-gold transition-all duration-300" />
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-sm font-medium text-paper/80 hover:text-gold transition-colors gold-underline"
            >
              {link.name}
            </a>
          ))}
          <a 
            href="#packages" 
            className="bg-gold hover:bg-gold-light text-navy-dark px-6 py-2 rounded-full text-sm font-semibold transition-all duration-300 shadow-lg shadow-gold/20"
          >
            Book Now
          </a>
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-gold"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 w-full bg-navy-dark border-b border-gold/10 p-6 md:hidden"
          >
            <div className="flex flex-col space-y-4">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  className="text-lg font-medium text-paper/80 hover:text-gold"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.name}
                </a>
              ))}
              <a 
                href="#packages" 
                className="bg-gold text-navy-dark px-6 py-3 rounded-full text-center font-semibold"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Book Now
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  return (
    <section id="hero" className="relative h-screen min-h-[700px] flex items-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://picsum.photos/seed/aerial-coast/1920/1080" 
          alt="Aerial Coastline" 
          className="w-full h-full object-cover opacity-40 scale-105 animate-pulse-slow"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-navy-dark/60 via-navy-dark/40 to-navy-dark" />
      </div>

      <div className="container mx-auto px-6 relative z-10 pt-20">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl"
        >
          <span className="inline-block text-gold font-medium tracking-[0.2em] uppercase text-sm mb-4 border-l-2 border-gold pl-4">
            Dallas–Fort Worth · San Diego
          </span>
          <h1 className="text-6xl md:text-8xl font-display font-light leading-tight mb-6">
            See the world from <br />
            <span className="italic text-gold font-normal">above</span>
          </h1>
          <p className="text-xl md:text-2xl text-paper/70 font-light max-w-2xl mb-10 leading-relaxed">
            Professional aerial & interior photography in 4K. Capturing high-end real estate and cinematic perspectives since 2020.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 mb-16">
            <a 
              href="#packages" 
              className="bg-gold hover:bg-gold-light text-navy-dark px-10 py-4 rounded-full font-semibold text-lg transition-all duration-300 flex items-center justify-center group"
            >
              View Packages
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
            </a>
            <a 
              href="#contact" 
              className="border border-gold/50 hover:border-gold text-paper px-10 py-4 rounded-full font-semibold text-lg transition-all duration-300 flex items-center justify-center"
            >
              Get in Touch
            </a>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 pt-8 border-t border-paper/10">
            <div>
              <div className="text-3xl font-display text-gold mb-1">5+</div>
              <div className="text-xs uppercase tracking-widest text-paper/50">Years Experience</div>
            </div>
            <div>
              <div className="text-3xl font-display text-gold mb-1">4K</div>
              <div className="text-xs uppercase tracking-widest text-paper/50">Native Resolution</div>
            </div>
            <div>
              <div className="text-3xl font-display text-gold mb-1">2</div>
              <div className="text-xs uppercase tracking-widest text-paper/50">Major Markets</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const About = () => {
  return (
    <section id="about" className="py-24 bg-navy">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div>
              <h2 className="text-4xl md:text-5xl font-display mb-6">Elevating Your Perspective</h2>
              <div className="h-1 w-20 bg-gold mb-8" />
            </div>
            
            <p className="text-lg text-paper/70 leading-relaxed">
              Based in both Dallas–Fort Worth and San Diego, Danon Aerial Photography specializes in high-end real estate and cinematic drone services. We leverage sub-250g drone technology for maximum flexibility and safety, delivering stunning 4K stills and video that stand out in any market.
            </p>
            
            <ul className="space-y-4">
              {[
                '4K Ultra-HD Delivery',
                'MLS-Ready Formats',
                'Social Media Optimized Cuts',
                'Professional Interior Stills',
                'Fast 24-48 Hour Turnaround'
              ].map((item) => (
                <li key={item} className="flex items-center text-paper/90">
                  <div className="w-5 h-5 rounded-full bg-gold/20 flex items-center justify-center mr-3">
                    <Check size={12} className="text-gold" />
                  </div>
                  {item}
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="absolute -top-4 -left-4 w-full h-full border border-gold/20 rounded-2xl z-0" />
            <img 
              src="https://picsum.photos/seed/sandiego-pool/800/1000" 
              alt="Luxury San Diego Property" 
              className="relative z-10 rounded-2xl shadow-2xl w-full object-cover aspect-[4/5]"
              referrerPolicy="no-referrer"
            />
            <div className="absolute bottom-8 right-8 z-20 bg-navy-dark/90 backdrop-blur-md p-6 rounded-xl border border-gold/20 shadow-xl">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gold rounded-lg">
                  <Camera className="text-navy-dark" size={24} />
                </div>
                <div>
                  <div className="text-sm font-semibold text-gold">Featured Project</div>
                  <div className="text-xs text-paper/60 uppercase tracking-tighter">La Jolla, CA</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const Services = () => {
  return (
    <section id="services" className="py-24 bg-navy-dark">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl md:text-5xl font-display mb-6">Our Services</h2>
          <p className="text-paper/60 text-lg">
            Comprehensive visual solutions designed to showcase properties and brands from every angle.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {SERVICES.map((service, idx) => (
            <motion.div 
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="p-8 bg-navy-light border border-gold/10 rounded-2xl hover:border-gold/30 hover:bg-navy-lighter transition-all duration-300 group"
            >
              <div className="w-14 h-14 bg-gold/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-gold transition-colors duration-300">
                <service.icon className="text-gold group-hover:text-navy-dark transition-colors duration-300" size={28} />
              </div>
              <h3 className="text-xl font-display font-medium mb-4">{service.title}</h3>
              <p className="text-paper/50 text-sm leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Packages = () => {
  return (
    <section id="packages" className="py-24 bg-navy">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl md:text-5xl font-display mb-6">Pricing Packages</h2>
          <p className="text-paper/60 text-lg">
            Transparent pricing for professional results. Select a package to begin your booking.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {PACKAGES.map((pkg, idx) => (
            <motion.div 
              key={pkg.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className={`relative p-8 rounded-2xl border transition-all duration-300 flex flex-col ${
                pkg.featured 
                ? 'bg-navy-lighter border-gold shadow-2xl shadow-gold/10 scale-105 z-10' 
                : 'bg-navy-light border-gold/10 hover:border-gold/30'
              }`}
            >
              {pkg.featured && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gold text-navy-dark px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
                  Most Popular
                </div>
              )}
              
              <div className="mb-8">
                <h3 className="text-2xl font-display mb-2">{pkg.name}</h3>
                <div className="flex items-baseline">
                  <span className="text-4xl font-display text-gold">$</span>
                  <span className="text-5xl font-display text-gold">{pkg.price}</span>
                </div>
                <div className="text-xs text-paper/40 uppercase tracking-widest mt-2">{pkg.turnaround} Turnaround</div>
              </div>

              <ul className="space-y-4 mb-10 flex-grow">
                {pkg.deliverables.map((item) => (
                  <li key={item} className="flex items-start text-sm text-paper/70">
                    <Check size={16} className="text-gold mr-3 mt-0.5 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>

              <button 
                onClick={() => document.getElementById('stripe-pay')?.scrollIntoView({ behavior: 'smooth' })}
                className={`w-full py-4 rounded-xl font-semibold transition-all duration-300 ${
                  pkg.featured 
                  ? 'bg-gold text-navy-dark hover:bg-gold-light' 
                  : 'border border-gold text-gold hover:bg-gold hover:text-navy-dark'
                }`}
              >
                Book {pkg.name}
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const StripePayment = () => {
  return (
    <section id="stripe-pay" className="py-24 bg-navy-dark border-y border-gold/10">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-display mb-8">Secure Online Payment</h2>
          <p className="text-paper/60 mb-12">
            Ready to lock in your shoot? Select your package below to pay securely via Stripe. 
            Once payment is received, we will contact you within 2 hours to schedule your session.
          </p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {PACKAGES.map((pkg) => (
              <a 
                key={pkg.id}
                href={pkg.stripeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex flex-col items-center p-6 bg-navy-light border border-gold/10 rounded-xl hover:border-gold transition-all group"
              >
                <span className="text-sm font-medium text-paper/50 mb-2 group-hover:text-gold">{pkg.name}</span>
                <span className="text-2xl font-display text-gold">${pkg.price}</span>
                <div className="mt-4 text-[10px] uppercase tracking-widest text-paper/30 flex items-center">
                  Secure via Stripe <ArrowRight size={10} className="ml-1" />
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    market: 'Dallas–Fort Worth TX',
    packageInterest: 'Standard',
    details: ''
  });
  const [status, setStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('sending');

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        setStatus('success');
      } else {
        setStatus('error');
      }
    } catch (error) {
      console.error('Contact error:', error);
      setStatus('error');
    }
  };

  return (
    <section id="contact" className="py-24 bg-navy">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div>
            <h2 className="text-4xl md:text-5xl font-display mb-8">Get In Touch</h2>
            <p className="text-paper/60 text-lg mb-12">
              Have a custom project or a specific vision? Send us an inquiry and we'll get back to you within 24 hours.
            </p>

            <div className="space-y-8">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center text-gold">
                  <Mail size={20} />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-widest text-paper/40">Email Us</div>
                  <div className="text-paper font-medium">danonaerialphotography@gmail.com</div>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center text-gold">
                  <Phone size={20} />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-widest text-paper/40">Call or Text</div>
                  <div className="text-paper font-medium">858-395-0214</div>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center text-gold">
                  <MapPin size={20} />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-widest text-paper/40">Locations</div>
                  <div className="text-paper font-medium">Dallas–Fort Worth · San Diego</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-navy-light p-8 md:p-12 rounded-3xl border border-gold/10 shadow-2xl relative overflow-hidden">
            <AnimatePresence mode="wait">
              {status === 'success' ? (
                <motion.div 
                  key="success"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-12"
                >
                  <div className="w-20 h-20 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Check size={40} className="text-gold" />
                  </div>
                  <h3 className="text-3xl font-display mb-4">Message Sent</h3>
                  <p className="text-paper/60">
                    Thank you for reaching out. We have received your inquiry and will be in touch shortly.
                  </p>
                  <button 
                    onClick={() => setStatus('idle')}
                    className="mt-8 text-gold hover:text-gold-light font-semibold underline underline-offset-8"
                  >
                    Send another message
                  </button>
                </motion.div>
              ) : (
                <motion.form 
                  key="form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onSubmit={handleSubmit} 
                  className="space-y-6"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs uppercase tracking-widest text-paper/50 ml-1">Full Name</label>
                      <input 
                        required
                        type="text" 
                        placeholder="John Doe"
                        className="w-full bg-navy-dark border border-gold/10 rounded-xl px-4 py-3 text-paper focus:outline-none focus:border-gold transition-colors"
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs uppercase tracking-widest text-paper/50 ml-1">Email Address</label>
                      <input 
                        required
                        type="email" 
                        placeholder="john@example.com"
                        className="w-full bg-navy-dark border border-gold/10 rounded-xl px-4 py-3 text-paper focus:outline-none focus:border-gold transition-colors"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs uppercase tracking-widest text-paper/50 ml-1">Market</label>
                      <select 
                        className="w-full bg-navy-dark border border-gold/10 rounded-xl px-4 py-3 text-paper focus:outline-none focus:border-gold transition-colors appearance-none"
                        value={formData.market}
                        onChange={(e) => setFormData({...formData, market: e.target.value})}
                      >
                        <option>Dallas–Fort Worth TX</option>
                        <option>San Diego CA</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs uppercase tracking-widest text-paper/50 ml-1">Package Interest</label>
                      <select 
                        className="w-full bg-navy-dark border border-gold/10 rounded-xl px-4 py-3 text-paper focus:outline-none focus:border-gold transition-colors appearance-none"
                        value={formData.packageInterest}
                        onChange={(e) => setFormData({...formData, packageInterest: e.target.value})}
                      >
                        <option>Starter</option>
                        <option>Standard</option>
                        <option>Premium</option>
                        <option>Full Production</option>
                        <option>Custom Quote</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-widest text-paper/50 ml-1">Project Details</label>
                    <textarea 
                      rows={4}
                      placeholder="Tell us about your property or project..."
                      className="w-full bg-navy-dark border border-gold/10 rounded-xl px-4 py-3 text-paper focus:outline-none focus:border-gold transition-colors resize-none"
                      value={formData.details}
                      onChange={(e) => setFormData({...formData, details: e.target.value})}
                    />
                  </div>

                  <button 
                    disabled={status === 'sending'}
                    type="submit"
                    className="w-full bg-gold hover:bg-gold-light text-navy-dark py-4 rounded-xl font-bold text-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                  >
                    {status === 'sending' ? 'Sending...' : 'Send Inquiry'}
                  </button>
                  
                  {status === 'error' && (
                    <p className="text-red-400 text-sm text-center">Something went wrong. Please try again.</p>
                  )}
                </motion.form>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-12 bg-navy-dark border-t border-gold/10">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-8 md:space-y-0">
          <div className="flex flex-col items-center md:items-start">
            <span className="text-xl font-display font-medium tracking-wider text-gold mb-2">
              DANON AERIAL
            </span>
            <div className="text-xs text-paper/40 uppercase tracking-widest">
              Dallas–Fort Worth · San Diego
            </div>
          </div>

          <div className="text-sm text-paper/40">
            © {new Date().getFullYear()} Danon Aerial Photography. All rights reserved.
          </div>

          <div className="flex space-x-8">
            <a href="#about" className="text-xs uppercase tracking-widest text-paper/60 hover:text-gold transition-colors">About</a>
            <a href="#services" className="text-xs uppercase tracking-widest text-paper/60 hover:text-gold transition-colors">Services</a>
            <a href="#contact" className="text-xs uppercase tracking-widest text-paper/60 hover:text-gold transition-colors">Privacy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <About />
      <Services />
      <Packages />
      <StripePayment />
      <Contact />
      <Footer />
    </div>
  );
}
